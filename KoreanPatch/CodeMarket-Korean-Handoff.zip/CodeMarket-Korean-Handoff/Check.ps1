﻿param([string]$GameDirectory)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Find-Game.ps1')
$game = Resolve-CodeMarketDirectory -GameDirectory $GameDirectory
& (Join-Path $PSScriptRoot 'Validate.ps1')
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'patched\patch-manifest.json') -Raw | ConvertFrom-Json
Write-Output "GameDirectory: $game"
foreach ($name in @('JavaMarket.Java.dll','JavaMarket.dll')) {
    $hash = (Get-FileHash -LiteralPath (Join-Path $game "Code Market_Data\Managed\$name")).Hash
    $status = 'UNSUPPORTED - inspect version before installation'
    if ($hash -eq $manifest.source.$name) { $status = 'ORIGINAL - compatible' }
    elseif ($hash -eq $manifest.patched.$name) { $status = 'PATCHED - compatible; local original backup required' }
    Write-Output "$name : $status"
}
foreach ($name in @('KoreanPatch.Runtime.dll','patched\JavaMarket.Java.dll','patched\JavaMarket.dll')) {
    $expected = $manifest.helperSha256
    if ($name -like 'patched\*') { $expected = $manifest.patched.([IO.Path]::GetFileName($name)) }
    if ((Get-FileHash -LiteralPath (Join-Path $PSScriptRoot $name)).Hash -ne $expected) { throw "Package binary hash mismatch: $name" }
}
Add-Type -AssemblyName System.Drawing
$collection = [Drawing.Text.InstalledFontCollection]::new()
try {
    $names = @($collection.Families | ForEach-Object Name)
    $uiFont = @($names | Where-Object { $_ -in @('Malgun Gothic','맑은 고딕','Noto Sans KR','Arial Unicode MS') })
    $monoFont = @($names | Where-Object { $_ -in @('GulimChe','굴림체','DotumChe','돋움체') })
    Write-Output ('Korean UI font candidates: ' + ($uiFont -join ', '))
    Write-Output ('Korean monospace font candidates: ' + ($monoFont -join ', '))
    if (-not $uiFont -or -not $monoFont) { Write-Warning 'Korean font support needs inspection on this computer. See AI-HANDOFF.txt.' }
} finally { $collection.Dispose() }
Write-Output 'CHECK FINISHED. This command did not install or alter game files.'
