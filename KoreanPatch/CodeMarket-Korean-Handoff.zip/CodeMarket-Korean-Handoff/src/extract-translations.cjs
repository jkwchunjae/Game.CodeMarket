const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const game = process.argv[2];
if (!game || !process.argv[3]) throw new Error('Usage: node extract-translations.cjs <game-directory> <empty-output-directory>');
const out = path.resolve(process.argv[3]);
const input = path.join(game, 'Code Market_Data', 'resources.assets');
const data = fs.readFileSync(input);
const tables = [];
// TextAssets have a length-prefixed UTF-8 script. Accept complete JSON only,
// and verify both the script length and the preceding aligned asset name.
for (let pos = 4; pos < data.length - 20; pos++) {
  if (data[pos] !== 123) continue;
  const size = data.readInt32LE(pos - 4);
  if (size < 20 || pos + size > data.length) continue;
  const head = data.subarray(pos, pos + 100).toString('utf8');
  if (!/^\{\s*"entries"\s*:/.test(head)) continue;
  let obj;
  try { obj = JSON.parse(data.subarray(pos, pos + size).toString('utf8')); } catch { continue; }
  if (!Array.isArray(obj.entries) || !obj.entries.every(e => typeof e.en === 'string')) continue;
  let name = null;
  for (let p = Math.max(0, pos - 260); p <= pos - 8; p += 1) {
    const n = data.readInt32LE(p);
    if (n < 1 || n > 240 || p + 4 + ((n + 3) & ~3) !== pos - 4) continue;
    const candidate = data.subarray(p + 4, p + 4 + n).toString('utf8');
    if (/^[A-Za-z0-9_.-]+$/.test(candidate)) name = candidate;
  }
  if (!name) throw new Error(`Missing TextAsset name at ${pos}`);
  tables.push({ name, offset: pos, bytes: size, entries: obj.entries });
  pos += size - 1;
}
if (!tables.length) throw new Error('No translation tables found');
fs.mkdirSync(out, { recursive: true });
if (fs.existsSync(path.join(out, 'ko.json'))) throw new Error('ko.json already exists. Choose an empty output directory to preserve your translations.');
const source = {
  game: 'Code Market',
  resourcesSha256: crypto.createHash('sha256').update(data).digest('hex'),
  tables
};
fs.writeFileSync(path.join(out, 'source-strings.json'), JSON.stringify(source, null, 2) + '\n');
const translations = {
  description: 'ko에 한국어 번역을 입력하세요. 빈 문자열은 영어 원문을 유지합니다. en, table, at는 수정하지 마세요. {0} 등의 치환 기호와 코드/태그는 보존하세요.',
  entries: [...new Map(tables.flatMap(t => t.entries.map((e, index) => [JSON.stringify([t.name, index, e.at || '', e.en]), { table: t.name, index, at: e.at || '', en: e.en, ko: '' }]))).values()]
};
fs.writeFileSync(path.join(out, 'ko.json'), JSON.stringify(translations, null, 2) + '\n');
console.log(JSON.stringify({ embeddedTables: tables.length, uniqueTables: new Set(tables.map(t=>t.name)).size, entries: translations.entries.length, sha256:source.resourcesSha256 }, null, 2));
