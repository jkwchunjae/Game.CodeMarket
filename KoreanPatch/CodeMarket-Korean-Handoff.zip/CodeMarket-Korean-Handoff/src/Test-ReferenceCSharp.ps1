﻿param(
    [string]$PackageDirectory,
    [string]$ManagedDirectory
)
$ErrorActionPreference = 'Stop'
# Run in a fresh PowerShell process. Reflection test state stays inside that process.
# This does not launch the game, call Unity native APIs, or change installed files.
if (-not $PackageDirectory) { $PackageDirectory = Split-Path $PSScriptRoot -Parent }
$package = (Resolve-Path -LiteralPath $PackageDirectory).Path
if (-not $ManagedDirectory) {
    . (Join-Path $package 'Find-Game.ps1')
    $ManagedDirectory = Join-Path (Resolve-CodeMarketDirectory) 'Code Market_Data\Managed'
}
$managed = (Resolve-Path -LiteralPath $ManagedDirectory).Path
$document = Get-Content -LiteralPath (Join-Path $package 'ko.json') -Raw -Encoding utf8 | ConvertFrom-Json
$entries = @($document.entries)
$guide = @($entries | Where-Object { $_.table -eq 'App.ReferenceCatalog' -and $_.en -ceq 'Guide' })
$title = @($entries | Where-Object { $_.table -eq 'App.ReferenceCatalog' -and $_.en -ceq 'First program' })
$body = @($entries | Where-Object { $_.table -eq 'App.ReferenceCatalog' -and $_.en -match '^\s*The robot obeys code in Java\.' })
foreach ($item in @(@{Name='Guide'; Entries=$guide}, @{Name='First program'; Entries=$title}, @{Name='Guide body'; Entries=$body})) {
    if ($item.Entries.Count -ne 1 -or [string]::IsNullOrWhiteSpace($item.Entries[0].ko)) {
        throw ('Expected one translated App.ReferenceCatalog entry for ' + $item.Name)
    }
}
foreach ($name in @('UnityEngine.CoreModule.dll','UnityEngine.TextRenderingModule.dll','UnityEngine.UI.dll')) {
    [Reflection.Assembly]::LoadFrom((Join-Path $managed $name)) | Out-Null
}
[Reflection.Assembly]::LoadFrom((Join-Path $package 'KoreanPatch.Runtime.dll')) | Out-Null
$java = [Reflection.Assembly]::LoadFrom((Join-Path $package 'patched\JavaMarket.Java.dll'))
foreach ($name in @('JavaMarket.CSharp.dll','JavaMarket.Cpp.dll')) {
    [Reflection.Assembly]::LoadFrom((Join-Path $managed $name)) | Out-Null
}
$app = [Reflection.Assembly]::LoadFrom((Join-Path $package 'patched\JavaMarket.dll'))
$runtime = [Type]::GetType('KoreanPatch.Runtime, KoreanPatch.Runtime', $true)
$private = [Reflection.BindingFlags]'NonPublic,Static'
$allStatic = [Reflection.BindingFlags]'NonPublic,Public,Static'
$runtime.GetField('loaded',$private).SetValue($null,$true)
$dictionary = $runtime.GetField('translations',$private).GetValue($null)
$dictionary.Clear()
foreach ($entry in $entries) {
    if ([string]::IsNullOrEmpty($entry.en) -or [string]::IsNullOrWhiteSpace($entry.ko)) { continue }
    $dictionary[$entry.en.Replace("`r`n","`n").Replace("`r","`n")] = $entry.ko
}
$loc = $java.GetType('JavaMarket.Loc',$true)
$language = $java.GetType('JavaMarket.GameLanguage',$true)
$loc.GetProperty('Current').SetValue($null,[Enum]::ToObject($language,1))
$code = $app.GetType('JavaMarket.Scripting.CodeText',$true)
$codeLanguage = $app.GetType('JavaMarket.Scripting.CodeLanguage',$true)
$code.GetField('Current').SetValue($null,[Enum]::ToObject($codeLanguage,0))
$translate = $loc.GetMethod('T')
$firstText = $translate.Invoke($null,@('RUSSIAN TEST PLACEHOLDER',$body[0].en))
$firstTitle = $translate.Invoke($null,@('RUSSIAN TEST PLACEHOLDER',$title[0].en))
$sectionTitle = $translate.Invoke($null,@('RUSSIAN TEST PLACEHOLDER',$guide[0].en))
$script:passed = 0
function Assert-Reference([string]$Name,[bool]$Condition) {
    if (-not $Condition) { throw "FAIL $Name" }
    $script:passed++
    Write-Output "PASS $Name"
}
Assert-Reference 'Guide section title translated before conversion' ($sectionTitle -ceq $guide[0].ko -and $sectionTitle -match '[가-힣]')
Assert-Reference 'First program title translated before conversion' ($firstTitle -ceq $title[0].ko -and $firstTitle -match '[가-힣]')
Assert-Reference 'Java prose translated before conversion' ($firstText -ceq $body[0].ko -and $firstText -match '[가-힣]' -and $firstText -match 'Java')
Assert-Reference 'Java example still Java before conversion' ($firstText -match 'robot\.move\(Direction\.UP\)')
$code.GetField('Current').SetValue($null,[Enum]::ToObject($codeLanguage,1))
$converted = $code.GetMethod('Page',$allStatic).Invoke($null,@($firstText))
$convertedTitle = $code.GetMethod('Prose',$allStatic).Invoke($null,@($firstTitle))
Assert-Reference 'CSharp title remains Korean' ($convertedTitle -ceq $title[0].ko -and $convertedTitle -match '[가-힣]')
Assert-Reference 'CSharp prose remains Korean' ($converted -match '[가-힣]' -and $converted -match 'C#')
Assert-Reference 'CSharp example converted to Move' ($converted -match 'robot\.Move\(Direction\.Up\)')
Assert-Reference 'CSharp print converted to Console.WriteLine' ($converted -match 'Console\.WriteLine')
Assert-Reference 'Original English opening absent' ($converted -notmatch 'The robot obeys code')
Write-Output "$script:passed assertions passed against actual Loc and CodeText.Page/Prose."
