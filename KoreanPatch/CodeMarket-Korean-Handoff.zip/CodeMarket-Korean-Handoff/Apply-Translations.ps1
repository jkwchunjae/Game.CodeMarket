﻿param([string]$GameDirectory)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Find-Game.ps1')
$game = Resolve-CodeMarketDirectory -GameDirectory $GameDirectory
& (Join-Path $PSScriptRoot 'Validate.ps1')
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'patched\patch-manifest.json') -Raw | ConvertFrom-Json
foreach ($name in @('JavaMarket.Java.dll','JavaMarket.dll')) {
    if ((Get-FileHash -LiteralPath (Join-Path $game "Code Market_Data\Managed\$name")).Hash -ne $manifest.patched.$name) {
        throw "Installed game patch does not match this kit: $name. Use Check.ps1 before installing."
    }
}
if ((Get-FileHash -LiteralPath (Join-Path $game 'Code Market_Data\Managed\KoreanPatch.Runtime.dll')).Hash -ne $manifest.helperSha256) {
    throw 'Installed runtime does not match this kit.'
}
$state = Join-Path $game 'KoreanPatch'
$target = Join-Path $state 'ko.json'
if (-not (Test-Path -LiteralPath $target)) { throw 'Installed ko.json is missing. Use Install.ps1 with the game closed.' }
$source = Join-Path $PSScriptRoot 'ko.json'
if ((Get-FileHash -LiteralPath $source).Hash -eq (Get-FileHash -LiteralPath $target).Hash) {
    Write-Output 'Translations are already synchronized. Restart the game if it was open during the update.'
    return
}
$history = Join-Path $state ('history\' + [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss-fff') + '-' + [Guid]::NewGuid().ToString('N') + '-translation')
New-Item -ItemType Directory -Path $history -Force | Out-Null
$temporary = Join-Path $state ('ko-' + [Guid]::NewGuid().ToString('N') + '.tmp')
try {
    Copy-Item -LiteralPath $source -Destination $temporary
    if ((Get-FileHash -LiteralPath $temporary).Hash -ne (Get-FileHash -LiteralPath $source).Hash) { throw 'Translation copy hash mismatch.' }
    # Replace the complete file and retain the previous translation in one operation.
    [IO.File]::Replace($temporary, $target, (Join-Path $history 'ko.json'))
    if ((Get-FileHash -LiteralPath $target).Hash -ne (Get-FileHash -LiteralPath $source).Hash) { throw 'Installed translation hash mismatch.' }
} finally {
    if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary }
}
Write-Output 'TRANSLATIONS UPDATED. Game DLLs and saves were not changed. Restart the game to load the new text.'
