﻿param([string]$TranslationFile)
$ErrorActionPreference = 'Stop'
if (-not $TranslationFile) { $TranslationFile = Join-Path $PSScriptRoot 'ko.json' }
$document = Get-Content -LiteralPath $TranslationFile -Raw -Encoding utf8 | ConvertFrom-Json
$source = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'source-strings.json') -Raw -Encoding utf8 | ConvertFrom-Json
function Get-Key($entry) { return (@($entry.table, [string]$entry.index, $entry.en) | ConvertTo-Json -Compress) }
function Get-Tokens([string]$text, [string]$pattern) {
    return (([regex]::Matches($text, $pattern) | ForEach-Object Value | Sort-Object) -join "`n")
}
$known = @{}
foreach ($table in $source.tables) {
    for ($i = 0; $i -lt $table.entries.Count; $i++) {
        $item = $table.entries[$i]
        $known[(Get-Key @{table=$table.name;index=$i;en=$item.en})] = $item
    }
}
if ($document.entries.Count -ne $known.Count) { throw "Expected $($known.Count) entries, got $($document.entries.Count)" }
$seen = @{}; $dictionary = [Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal); $translated = 0
foreach ($entry in $document.entries) {
    $key = Get-Key $entry
    if (-not $known.ContainsKey($key) -or $seen.ContainsKey($key)) { throw "Unknown or duplicate entry: $($entry.table):$($entry.index)" }
    $seen[$key] = $true
    if ($entry.ko -isnot [string]) { throw "ko must be a string: $key" }
    if ([string]::IsNullOrWhiteSpace($entry.ko)) { continue }
    $original = $known[$key]
    $pattern = '(?<!\{)\{\d+(?:,[^{}]+)?(?::[^{}]+)?\}(?!\})'
    if ((Get-Tokens $entry.en $pattern) -cne (Get-Tokens $entry.ko $pattern)) { throw "Placeholder mismatch: $($entry.table):$($entry.index)" }
    $tagPattern = '</?(?:b|i|color|size|material|quad)(?:=[^>]+|\s[^>]+)?>'
    if ((Get-Tokens $entry.en $tagPattern) -cne (Get-Tokens $entry.ko $tagPattern)) { throw "Rich-text tag mismatch: $($entry.table):$($entry.index)" }
    if ($original.format) {
        $matches = [regex]::Matches($entry.en, '(?<!\{)\{(\d+)')
        $maxIndex = -1
        foreach ($match in $matches) { $maxIndex = [Math]::Max($maxIndex, [int]$match.Groups[1].Value) }
        $values = [object[]]::new($maxIndex + 1)
        for ($i = 0; $i -lt $values.Length; $i++) { $values[$i] = 1 }
        try { $null = [string]::Format($entry.ko, $values) } catch { throw "Invalid format string: $($entry.table):$($entry.index): $_" }
    }
    $english = $entry.en.Replace("`r`n", "`n").Replace("`r", "`n")
    if ($dictionary.ContainsKey($english) -and $dictionary[$english] -cne $entry.ko) { throw "Conflicting translations for identical English: $english" }
    $dictionary[$english] = $entry.ko
    $translated++
}
Write-Output "VALID: $translated / $($known.Count) translated; $($dictionary.Count) unique translated English keys."
