﻿param([string]$GameDirectory)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Find-Game.ps1')
$game = Resolve-CodeMarketDirectory -GameDirectory $GameDirectory
if (Get-Process -Name 'Code Market' -ErrorAction SilentlyContinue) { throw 'Close Code Market before uninstalling.' }
$managed = Join-Path $game 'Code Market_Data\Managed'
$state = Join-Path $game 'KoreanPatch'
$manifest = Get-Content -LiteralPath (Join-Path $state 'installed-manifest.json') -Raw | ConvertFrom-Json
$names = @('JavaMarket.Java.dll','JavaMarket.dll')
$backupKey = $manifest.source.'JavaMarket.Java.dll'.Substring(0,16) + '-' + $manifest.source.'JavaMarket.dll'.Substring(0,16)
$backup = Join-Path $state ('originals\' + $backupKey)
if (-not (Test-Path -LiteralPath $backup)) { $backup = Join-Path $state 'originals' }
foreach ($name in $names) {
    $current = (Get-FileHash -LiteralPath (Join-Path $managed $name) -Algorithm SHA256).Hash
    if ($current -ne $manifest.patched.$name -and $current -ne $manifest.source.$name) { throw "Game changed since installation; refusing to overwrite: $name" }
    if ((Get-FileHash -LiteralPath (Join-Path $backup $name) -Algorithm SHA256).Hash -ne $manifest.source.$name) { throw "Backup hash mismatch: $name" }
}
foreach ($name in $names) {
    Copy-Item -LiteralPath (Join-Path $backup $name) -Destination (Join-Path $managed $name) -Force
    if ((Get-FileHash -LiteralPath (Join-Path $managed $name) -Algorithm SHA256).Hash -ne $manifest.source.$name) { throw "Restore failed: $name" }
}
$helper = Join-Path $managed 'KoreanPatch.Runtime.dll'
if (Test-Path -LiteralPath $helper) {
    if ((Get-FileHash -LiteralPath $helper -Algorithm SHA256).Hash -eq $manifest.helperSha256) { Remove-Item -LiteralPath $helper }
    else { Write-Warning 'Changed Runtime DLL was preserved. Restored game DLLs do not reference it.' }
}
Write-Output 'RESTORED original DLLs. Translation files and original backups were preserved in KoreanPatch.'
