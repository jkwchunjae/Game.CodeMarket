Mono.Cecil 0.11.5 — optional source patching tool
Copyright: Jb Evain and Novell, Inc. See LICENSE.txt (MIT).
Official project: https://github.com/jbevain/cecil
Exact license: https://github.com/jbevain/cecil/blob/0.11.5/LICENSE.txt
Package: https://www.nuget.org/packages/Mono.Cecil/0.11.5

Files copied from the locally cached official NuGet package Mono.Cecil 0.11.5.
net40/Mono.Cecil.dll: Windows PowerShell 5 / .NET Framework.
netstandard2.0/Mono.Cecil.dll: PowerShell 7 / modern .NET.
Not used by ordinary Install.ps1, Validate.ps1 or Uninstall.ps1.
