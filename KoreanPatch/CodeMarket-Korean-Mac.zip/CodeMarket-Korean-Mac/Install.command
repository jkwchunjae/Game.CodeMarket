#!/bin/zsh
cd -- "${0:A:h}" || exit 1
/usr/bin/python3 ./install.py
result=$?
printf '\n창을 닫으려면 Enter를 누르세요. '
read answer
exit $result
