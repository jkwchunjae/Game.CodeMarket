#!/usr/bin/env python3
import hashlib, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path
from datetime import datetime
KIT=Path(__file__).resolve().parent
DEFAULT=Path.home()/'Library/Application Support/Steam/steamapps/common/Code Market/Code Market.app'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def require(ok,msg):
 if not ok: raise RuntimeError(msg)
def atomic(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 fd,tmp=tempfile.mkstemp(prefix='.korean-',dir=str(dst.parent));os.close(fd)
 try:
  shutil.copy2(src,tmp);os.replace(tmp,dst)
 finally:
  if os.path.exists(tmp): os.unlink(tmp)
def main():
 undo='--uninstall' in sys.argv
 args=[a for a in sys.argv[1:] if a!='--uninstall']
 app=Path(args[0]).expanduser().resolve() if args else DEFAULT
 resources=app/'Contents/Resources';managed=resources/'Data/Managed'
 require(managed.is_dir(),'게임 설치 위치를 찾지 못했습니다: '+str(app))
 proc=subprocess.run(['/usr/bin/pgrep','-x','Java Supermarket'],capture_output=True)
 require(proc.returncode==1,'게임을 저장하고 완전히 종료한 뒤 다시 실행하세요. (실행 여부 확인 실패 시에도 중단합니다.)')
 manifest=json.loads((KIT/'patched/patch-manifest.json').read_text(encoding='utf-8-sig'))
 state=app.parent/'KoreanPatch-Mac'
 originals=state/'originals'/('-'.join(manifest['source'][n][:16] for n in sorted(manifest['source'])))
 targets={n:managed/n for n in manifest['source']}
 targets['KoreanPatch.Runtime.dll']=managed/'KoreanPatch.Runtime.dll'
 targets['ko.json']=resources/'KoreanPatch/ko.json'
 require(digest(KIT/'KoreanPatch.Runtime.dll')==manifest['helperSha256'],'패치 런타임 무결성 오류')
 for n,h in manifest['patched'].items(): require(digest(KIT/'patched'/n)==h,'패치 파일 무결성 오류: '+n)
 current={n:digest(managed/n) for n in manifest['source']}
 pristine=current==manifest['source'];patched=current==manifest['patched']
 require(pristine or patched,'게임 버전이 다르거나 다른 모드가 설치되어 있습니다. 아무 파일도 변경하지 않았습니다.')
 if undo:
  require(patched,'현재 이 패치가 설치된 상태가 아닙니다.')
  require(targets['KoreanPatch.Runtime.dll'].exists() and digest(targets['KoreanPatch.Runtime.dll'])==manifest['helperSha256'],'런타임이 달라 원복을 중단합니다.')
 else:
  for n in ('ko.json','KoreanPatch.Runtime.dll'):
   if targets[n].exists(): require(digest(targets[n])==digest(KIT/n),'기존 번역 또는 런타임이 다릅니다. 보존을 위해 중단합니다: '+n)
 if pristine:
  originals.mkdir(parents=True,exist_ok=True)
  for n,h in manifest['source'].items():
   if (originals/n).exists(): require(digest(originals/n)==h,'원본 백업 무결성 오류')
   else: shutil.copy2(managed/n,originals/n)
 for n,h in manifest['source'].items(): require((originals/n).exists() and digest(originals/n)==h,'검증된 원본 백업이 없습니다: '+n)
 history=state/'history'/(datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
 history.mkdir(parents=True)
 existed={n:p.exists() for n,p in targets.items()}
 for n,p in targets.items():
  if p.exists(): shutil.copy2(p,history/n)
 shutil.copy2(KIT/'patched/patch-manifest.json',state/'patch-manifest.json')
 try:
  for n in manifest['source']: atomic((originals if undo else KIT/'patched')/n,targets[n])
  if undo: targets['KoreanPatch.Runtime.dll'].unlink()
  else:
   atomic(KIT/'KoreanPatch.Runtime.dll',targets['KoreanPatch.Runtime.dll'])
   atomic(KIT/'ko.json',targets['ko.json'])
  for n,h in (manifest['source'] if undo else manifest['patched']).items(): require(digest(targets[n])==h,'설치 후 검증 실패: '+n)
  if not undo:
   for n in ('ko.json','KoreanPatch.Runtime.dll'): require(digest(targets[n])==digest(KIT/n),'설치 후 검증 실패: '+n)
 except BaseException:
  for n,p in targets.items():
   if existed[n]: atomic(history/n,p)
   elif p.exists(): p.unlink()
  raise
 print('원복 완료. 번역 파일과 백업은 보존했습니다.' if undo else '한국어 패치 설치 완료! Steam에서 게임을 실행하고 언어를 English로 선택하세요.')
 print('백업: '+str(originals))
if __name__=='__main__':
 try: main()
 except Exception as e: print('중단: '+str(e),file=sys.stderr);sys.exit(1)
