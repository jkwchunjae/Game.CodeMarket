using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using UnityEngine;

namespace KoreanPatch
{
    public static class Runtime
    {
        [DataContract] public sealed class TranslationFile { [DataMember] public Entry[] entries; }
        [DataContract] public sealed class Entry { [DataMember] public string en; [DataMember] public string ko; }
        private static readonly Dictionary<string, string> translations = new Dictionary<string, string>(StringComparer.Ordinal);
        private static readonly Font[] fonts = new Font[3];
        private static readonly Regex placeholders = new Regex(@"(?<!\{)\{(\d+)(?:,[^{}]+)?(?::[^{}]+)?\}(?!\})");
        private static bool loaded;
        private static bool probeChecked;

        private static string Normalize(string value) { return value.Replace("\r\n", "\n").Replace("\r", "\n"); }

        public static string Translate(string english)
        {
            if (String.IsNullOrEmpty(english)) return english;
            if (!loaded) Load();
            string result;
            return translations.TryGetValue(Normalize(english), out result) ? result : english;
        }

        public static string Format(FormattableString english)
        {
            if (english == null) return String.Empty;
            try { return String.Format(Translate(english.Format), english.GetArguments()); }
            catch (FormatException) { return english.ToString(); }
        }

        private static string PlaceholderSet(string text)
        {
            var result = new List<string>();
            foreach (Match match in placeholders.Matches(text)) result.Add(match.Groups[1].Value);
            result.Sort(StringComparer.Ordinal);
            return String.Join(",", result.ToArray());
        }

        private static void Load()
        {
            loaded = true;
            try
            {
                string file = Path.GetFullPath(Path.Combine(Path.GetDirectoryName(typeof(Runtime).Assembly.Location), "..", "..", "KoreanPatch", "ko.json"));
                TranslationFile document;
                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(File.ReadAllText(file))))
                    document = (TranslationFile)new DataContractJsonSerializer(typeof(TranslationFile)).ReadObject(stream);
                if (document == null || document.entries == null) throw new InvalidDataException("Missing entries array");
                var conflicts = new HashSet<string>(StringComparer.Ordinal);
                int rejected = 0;
                foreach (var entry in document.entries)
                {
                    if (entry == null || String.IsNullOrEmpty(entry.en) || String.IsNullOrWhiteSpace(entry.ko)) continue;
                    if (PlaceholderSet(entry.en) != PlaceholderSet(entry.ko)) { rejected++; continue; }
                    string key = Normalize(entry.en);
                    if (conflicts.Contains(key)) continue;
                    string existing;
                    if (translations.TryGetValue(key, out existing) && existing != entry.ko)
                    {
                        translations.Remove(key);
                        conflicts.Add(key);
                        continue;
                    }
                    translations[key] = entry.ko;
                }
                Debug.Log("[CodeMarket Korean] Loaded " + translations.Count + " translations; rejected=" + rejected + "; conflicts=" + conflicts.Count);
            }
            catch (Exception error)
            {
                translations.Clear();
                Debug.LogWarning("[CodeMarket Korean] English fallback: " + error.Message);
            }
        }

        public static Font GetFont(int kind)
        {
            if (!probeChecked)
            {
                probeChecked = true;
                if (Array.IndexOf(Environment.GetCommandLineArgs(), "-korean-patch-smoke") >= 0)
                {
                    var probe = new GameObject("KoreanPatchSmoke");
                    UnityEngine.Object.DontDestroyOnLoad(probe);
                    probe.AddComponent<SmokeProbe>();
                }
            }
            if (kind < 0 || kind >= fonts.Length) kind = 0;
            if (fonts[kind] != null) return fonts[kind];
            try
            {
                // Use installed macOS Korean fonts; do not redistribute font files.
                // OS fonts are referenced in place and never redistributed.
                string[] names = kind == 2
                    ? new [] { "Apple SD Gothic Neo", "AppleGothic", "Arial Unicode MS" }
                    : new [] { "Apple SD Gothic Neo", "AppleGothic", "Arial Unicode MS" };
                fonts[kind] = Font.CreateDynamicFontFromOSFont(names, 20);
                fonts[kind].RequestCharactersInTexture("한국어 가나다Wi", 20, FontStyle.Normal);
                CharacterInfo wide, narrow;
                fonts[kind].GetCharacterInfo('W', out wide, 20, FontStyle.Normal);
                fonts[kind].GetCharacterInfo('i', out narrow, 20, FontStyle.Normal);
                Debug.Log("[CodeMarket Korean] Font kind=" + kind + " name=" + fonts[kind].name + " Hangul=" + fonts[kind].HasCharacter('한') + " advance(W/i)=" + wide.advance + "/" + narrow.advance);
                return fonts[kind];
            }
            catch (Exception error)
            {
                Debug.LogWarning("[CodeMarket Korean] Font fallback: " + error.Message);
                return null;
            }
        }
    }

    // Only enabled by an explicit test flag; normal gameplay creates no probe.
    public sealed class SmokeProbe : MonoBehaviour
    {
        private System.Collections.IEnumerator Start()
        {
            yield return new WaitForSecondsRealtime(6);
            int korean = 0;
            foreach (var label in Resources.FindObjectsOfTypeAll<UnityEngine.UI.Text>())
            {
                if (label.gameObject.activeInHierarchy && Regex.IsMatch(label.text ?? "", "[가-힣]"))
                {
                    korean++;
                    Debug.Log("[CodeMarket Korean SMOKE] Label: " + label.text);
                }
            }
            var mono = Runtime.GetFont(2);
            Debug.Log("[CodeMarket Korean SMOKE] Korean labels=" + korean + "; Play=" + Runtime.Translate("Play"));
            var args = Environment.GetCommandLineArgs();
            int capture = Array.IndexOf(args, "-korean-patch-capture");
            if (capture >= 0 && capture + 1 < args.Length) ScreenCapture.CaptureScreenshot(args[capture + 1]);
            yield return new WaitForSecondsRealtime(2);
            Application.Quit(korean > 0 && mono != null && mono.HasCharacter('한') ? 0 : 2);
        }
    }
}
