﻿param([string]$GameDirectory)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Find-Game.ps1')
$game = Resolve-CodeMarketDirectory -GameDirectory $GameDirectory
& (Join-Path $PSScriptRoot 'Validate.ps1')
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'patched\patch-manifest.json') -Raw | ConvertFrom-Json
Write-Output "GameDirectory: $game"
foreach ($name in @('JavaMarket.Java.dll','JavaMarket.dll')) {
    $hash = (Get-FileHash -LiteralPath (Join-Path $game "Code Market_Data\Managed\$name")).Hash
    $status = 'UNSUPPORTED - inspect version before installation'
    if ($hash -eq $manifest.source.$name) { $status = 'ORIGINAL - compatible' }
    elseif ($hash -eq $manifest.patched.$name) { $status = 'PATCHED - compatible; local original backup required' }
    Write-Output "$name : $status"
}
foreach ($name in @('PortuguesePatch.Runtime.dll','patched\JavaMarket.Java.dll','patched\JavaMarket.dll')) {
    $expected = $manifest.helperSha256
    if ($name -like 'patched\*') { $expected = $manifest.patched.([IO.Path]::GetFileName($name)) }
    if ((Get-FileHash -LiteralPath (Join-Path $PSScriptRoot $name)).Hash -ne $expected) { throw "Package binary hash mismatch: $name" }
}
Write-Output 'CHECK FINISHED. Nenhum arquivo do jogo foi alterado.'
