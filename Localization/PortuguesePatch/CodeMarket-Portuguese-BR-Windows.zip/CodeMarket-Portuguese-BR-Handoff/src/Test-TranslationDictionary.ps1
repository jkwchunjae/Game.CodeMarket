﻿param([string]$PackageDirectory, [Parameter(Mandatory=$true)][string]$ManagedDirectory)
$ErrorActionPreference = 'Stop'
if (-not $PackageDirectory) { $PackageDirectory = Split-Path $PSScriptRoot -Parent }
$package = (Resolve-Path $PackageDirectory).Path
foreach ($name in @('UnityEngine.CoreModule.dll','UnityEngine.TextRenderingModule.dll')) {
    [Reflection.Assembly]::LoadFrom((Join-Path $ManagedDirectory $name)) | Out-Null
}
$helper = [Reflection.Assembly]::LoadFrom((Join-Path $package 'PortuguesePatch.Runtime.dll'))
$runtime = $helper.GetType('PortuguesePatch.Runtime', $true)
$documentType = $helper.GetType('PortuguesePatch.Runtime+TranslationFile', $true)
$serializer = [Runtime.Serialization.Json.DataContractJsonSerializer]::new($documentType)
$stream = [IO.MemoryStream]::new([Text.Encoding]::UTF8.GetBytes([IO.File]::ReadAllText((Join-Path $package 'pt-BR.json'))))
try { $document = $serializer.ReadObject($stream) } finally { $stream.Dispose() }
if ($document.entries.Count -ne 2499) { throw 'Unexpected runtime deserialization count.' }
$flags = [Reflection.BindingFlags]'NonPublic,Static'
$runtime.GetField('loaded',$flags).SetValue($null,$true)
$dictionary = $runtime.GetField('translations',$flags).GetValue($null)
foreach ($entry in $document.entries) {
    if ([string]::IsNullOrWhiteSpace($entry.ptBR)) { throw 'Runtime ptBR field was empty.' }
    $dictionary[$entry.en.Replace("`r`n","`n").Replace("`r","`n")] = $entry.ptBR
}
$assembly = [Reflection.Assembly]::LoadFrom((Join-Path $package 'patched/JavaMarket.Java.dll'))
$loc = $assembly.GetType('JavaMarket.Loc', $true)
$language = $assembly.GetType('JavaMarket.GameLanguage', $true)
$loc.GetProperty('Current').SetValue($null,[Enum]::ToObject($language,1))
$translate = $loc.GetMethod('T')
foreach ($entry in $document.entries) {
    $result = $translate.Invoke($null,@('UNUSED RUSSIAN', $entry.en))
    if ($result -cne $entry.ptBR) { throw "Translation lookup failed: $($entry.en)" }
}
Write-Output "PASS actual runtime JSON deserialization and all $($document.entries.Count) patched Loc.T lookups."
