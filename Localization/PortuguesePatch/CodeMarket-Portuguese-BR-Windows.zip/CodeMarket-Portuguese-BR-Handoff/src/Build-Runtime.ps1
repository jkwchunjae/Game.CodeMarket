﻿param([string]$GameDirectory)
$ErrorActionPreference = 'Stop'
$package = Split-Path $PSScriptRoot -Parent
. (Join-Path $package 'Find-Game.ps1')
$GameDirectory = Resolve-CodeMarketDirectory -GameDirectory $GameDirectory
$managed = Join-Path $GameDirectory 'Code Market_Data\Managed'
$sdkLine = dotnet --list-sdks | Select-Object -Last 1
if (-not $sdkLine) { throw '.NET SDK is required to rebuild the optional source.' }
$sdk = $sdkLine -replace '^([^ ]+).*$', '$1'
$sdkRoot = $sdkLine -replace '^.*\[([^\]]+)\]$', '$1'
$compiler = Join-Path $sdkRoot "$sdk\Roslyn\bincore\csc.dll"
$references = @('mscorlib.dll','netstandard.dll','System.dll','System.Core.dll','System.Xml.dll','System.Runtime.Serialization.dll','UnityEngine.CoreModule.dll','UnityEngine.UIModule.dll','UnityEngine.UI.dll','UnityEngine.ScreenCaptureModule.dll','UnityEngine.TextRenderingModule.dll') | ForEach-Object { '/reference:"' + (Join-Path $managed $_) + '"' }
$arguments = @('/nologo','/target:library','/nostdlib+','/optimize+','/deterministic+',('/out:"' + (Join-Path $package 'PortuguesePatch.Runtime.dll') + '"')) + $references + @(('"' + (Join-Path $PSScriptRoot 'Runtime.cs') + '"'))
$response = Join-Path ([IO.Path]::GetTempPath()) ('codemarket-runtime-' + [Guid]::NewGuid().ToString('N') + '.rsp')
try {
    [IO.File]::WriteAllLines($response, $arguments, [Text.UTF8Encoding]::new($false))
    & dotnet $compiler "@$response"
    if ($LASTEXITCODE -ne 0) { throw 'Runtime compilation failed' }
} finally { if (Test-Path -LiteralPath $response) { Remove-Item -LiteralPath $response } }
Write-Output 'Runtime rebuilt. Regenerate patched copies/manifest with Patch-Portuguese-BR.ps1 before installation.'
