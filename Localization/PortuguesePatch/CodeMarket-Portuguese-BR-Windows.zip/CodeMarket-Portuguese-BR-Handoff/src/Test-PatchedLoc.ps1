﻿param(
    [string]$PackageDirectory,
    [string]$ManagedDirectory
)
$ErrorActionPreference = 'Stop'
if (-not $PackageDirectory) { $PackageDirectory = Split-Path $PSScriptRoot -Parent }
if (-not $ManagedDirectory) { . (Join-Path $PackageDirectory 'Find-Game.ps1'); $ManagedDirectory = Join-Path (Resolve-CodeMarketDirectory) 'Code Market_Data\Managed' }
$package = (Resolve-Path -LiteralPath $PackageDirectory).Path
foreach ($name in @('UnityEngine.CoreModule.dll','UnityEngine.TextRenderingModule.dll')) {
    [Reflection.Assembly]::LoadFrom((Join-Path $ManagedDirectory $name)) | Out-Null
}
[Reflection.Assembly]::LoadFrom((Join-Path $package 'PortuguesePatch.Runtime.dll')) | Out-Null
$assembly = [Reflection.Assembly]::LoadFrom((Join-Path $package 'patched/JavaMarket.Java.dll'))
$runtime = [Type]::GetType('PortuguesePatch.Runtime, PortuguesePatch.Runtime')
$flags = [Reflection.BindingFlags]'NonPublic,Static'
# Seed only in this test process: no Unity native methods or disk loader are invoked.
$runtime.GetField('loaded',$flags).SetValue($null,$true)
$dictionary = $runtime.GetField('translations',$flags).GetValue($null)
$dictionary['Hello'] = 'Olá'
$dictionary['Score {0}'] = 'Pontuação {0}'
$dictionary["Line`nTwo"] = "Linha`nDois"
$loc = $assembly.GetType('JavaMarket.Loc',$true)
$language = $assembly.GetType('JavaMarket.GameLanguage',$true)
$current = $loc.GetProperty('Current')
$t = $loc.GetMethod('T')
$f = $loc.GetMethod('F')
$formattable = [Runtime.CompilerServices.FormattableStringFactory]::Create('Score {0}', [object[]]@(7))
$script:passed = 0
function Assert-Text([string]$name, $actual, $expected) {
    if ($actual -cne $expected) { throw "$name failed: expected <$expected>, actual <$actual>" }
    $script:passed++
    Write-Output "PASS $name"
}
$current.SetValue($null,[Enum]::ToObject($language,1))
Assert-Text 'English T translation' ($t.Invoke($null,@('Привет','Hello'))) 'Olá'
Assert-Text 'English unknown fallback' ($t.Invoke($null,@('Неизвестно','Unknown'))) 'Unknown'
Assert-Text 'English null preserved' ($t.Invoke($null,@('Привет',$null))) $null
Assert-Text 'English F placeholders' ($f.Invoke($null,@('Счет 7',$formattable))) 'Pontuação 7'
Assert-Text 'CRLF lookup normalization' ($t.Invoke($null,@('Строки',"Line`r`nTwo"))) "Linha`nDois"
$dictionary['Score {0}'] = 'Pontuação {1}'
Assert-Text 'Malformed translated format fallback' ($f.Invoke($null,@('Счет 7',$formattable))) 'Score 7'
$current.SetValue($null,[Enum]::ToObject($language,0))
Assert-Text 'Russian T preserved' ($t.Invoke($null,@('Привет','Hello'))) 'Привет'
Assert-Text 'Russian F preserved' ($f.Invoke($null,@('Счет 7',$formattable))) 'Счет 7'
$current.SetValue($null,[Enum]::ToObject($language,2))
Assert-Text 'Japanese branch preserved' ($t.Invoke($null,@('Привет','Hello'))) 'Hello'
$current.SetValue($null,[Enum]::ToObject($language,3))
Assert-Text 'Chinese branch preserved' ($t.Invoke($null,@('Привет','Hello'))) 'Hello'
$current.SetValue($null,[Enum]::ToObject($language,4))
Assert-Text 'Spanish T branch preserved' ($t.Invoke($null,@('Привет','Hello'))) 'Hello'
Assert-Text 'Spanish F branch preserved' ($f.Invoke($null,@('Счет 7',$formattable))) 'Score 7'
$current.SetValue($null,[Enum]::ToObject($language,5))
Assert-Text 'Italian T branch preserved' ($t.Invoke($null,@('Привет','Hello'))) 'Hello'
Assert-Text 'Italian F branch preserved' ($f.Invoke($null,@('Счет 7',$formattable))) 'Score 7'
Write-Output "$script:passed assertions passed against actual patched Loc and actual Runtime assemblies."


