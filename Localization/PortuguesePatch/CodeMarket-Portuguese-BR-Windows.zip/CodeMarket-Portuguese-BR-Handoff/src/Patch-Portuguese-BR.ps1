﻿param(
    [Parameter(Mandatory=$true)][string]$ManagedDirectory,
    [Parameter(Mandatory=$true)][string]$RuntimeAssembly,
    [Parameter(Mandatory=$true)][string]$OutputDirectory,
    [string]$CecilAssembly
)
$ErrorActionPreference = 'Stop'
if (-not $CecilAssembly) { $CecilAssembly = Join-Path (Split-Path $PSScriptRoot -Parent) ('tools\cecil\' + $(if ($PSVersionTable.PSEdition -eq 'Desktop') { 'net40' } else { 'netstandard2.0' }) + '\Mono.Cecil.dll') }
Add-Type -Path $CecilAssembly
$managed = (Resolve-Path -LiteralPath $ManagedDirectory).Path
$runtimePath = (Resolve-Path -LiteralPath $RuntimeAssembly).Path
$output = [IO.Path]::GetFullPath($OutputDirectory)
if ($output.TrimEnd('\') -eq $managed.TrimEnd('\')) { throw 'OutputDirectory must differ from source Managed directory.' }
[IO.Directory]::CreateDirectory($output) | Out-Null
$resolver = [Mono.Cecil.DefaultAssemblyResolver]::new()
$resolver.AddSearchDirectory($managed)
$resolver.AddSearchDirectory([IO.Path]::GetDirectoryName($runtimePath))
$reader = [Mono.Cecil.ReaderParameters]::new()
$reader.AssemblyResolver = $resolver
$runtime = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($runtimePath,$reader)
$runtimeType = $runtime.MainModule.Types | Where-Object FullName -eq 'PortuguesePatch.Runtime'
$translate = @($runtimeType.Methods | Where-Object { $_.Name -eq 'Translate' -and $_.IsStatic -and $_.Parameters.Count -eq 1 -and $_.Parameters[0].ParameterType.FullName -eq 'System.String' -and $_.ReturnType.FullName -eq 'System.String' })
$getFont = @($runtimeType.Methods | Where-Object { $_.Name -eq 'GetFont' -and $_.IsStatic -and $_.Parameters.Count -eq 1 -and $_.Parameters[0].ParameterType.FullName -eq 'System.Int32' -and $_.ReturnType.FullName -eq 'UnityEngine.Font' })
if ($translate.Count -ne 1 -or $getFont.Count -ne 1) { throw 'Runtime API signatures do not match.' }
$runtimeName = $runtime.Name.Name
$javaPath = Join-Path $managed 'JavaMarket.Java.dll'
$appPath = Join-Path $managed 'JavaMarket.dll'
$java = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($javaPath,$reader)
$app = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($appPath,$reader)
foreach ($a in @($java,$app)) {
    if (@($a.MainModule.AssemblyReferences | Where-Object Name -eq $runtimeName).Count) { throw ('Already patched: ' + $a.Name.Name) }
    if ($a.Name.HasPublicKey) { throw ('Strong-named source requires a different patch strategy: ' + $a.Name.Name) }
}
$loc = $java.MainModule.Types | Where-Object FullName -eq 'JavaMarket.Loc'
$t = @($loc.Methods | Where-Object { $_.Name -eq 'T' -and $_.Parameters.Count -eq 2 -and $_.Parameters[1].ParameterType.FullName -eq 'System.String' })
$f = @($loc.Methods | Where-Object { $_.Name -eq 'F' -and $_.Parameters.Count -eq 2 -and $_.Parameters[1].ParameterType.FullName -eq 'System.FormattableString' })
if ($t.Count -ne 1 -or $f.Count -ne 1) { throw 'Loc.T/F signatures changed.' }
$t = $t[0]; $f = $f[0]
$language = $java.MainModule.Types | Where-Object FullName -eq 'JavaMarket.GameLanguage'
$englishValue = @($language.Fields | Where-Object { $_.Name -eq 'English' -and $_.HasConstant -and $_.Constant -eq 1 })
if ($englishValue.Count -ne 1) { throw 'GameLanguage.English is no longer 1.' }
function Test-EnglishReturnEntry($instruction) {
    # Supported original shape: switch-like branch jumps over the English return.
    if ($instruction.Previous.OpCode.Code -eq 'Br_S') { return $true }
    # Expanded-language builds test Russian first, then Current != English (1).
    $branch = $instruction.Previous
    return ($branch.OpCode.Code -eq 'Bne_Un_S' -and $branch.Previous.OpCode.Code -eq 'Ldc_I4_1' -and $branch.Previous.Previous.OpCode.Code -eq 'Ldloc_0' -and $branch.Operand -ne $instruction)
}
$translateRef = $java.MainModule.ImportReference($translate[0])
$tIns = @($t.Body.Instructions)
$englishLoad = @($tIns | Where-Object { $_.OpCode.Code -eq 'Ldarg_1' -and $_.Next.OpCode.Code -eq 'Ret' -and (Test-EnglishReturnEntry $_) })
if ($englishLoad.Count -ne 1) { throw 'Loc.T English branch shape changed.' }
$t.Body.GetILProcessor().InsertAfter($englishLoad[0], [Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Call,$translateRef))
$fIns = @($f.Body.Instructions)
$toString = @($fIns | Where-Object { $_.OpCode.Code -eq 'Callvirt' -and $_.Operand.FullName -eq 'System.String System.Object::ToString()' -and $_.Previous.OpCode.Code -eq 'Ldarg_1' -and (Test-EnglishReturnEntry $_.Previous) })
if ($toString.Count -ne 1 -or $toString[0].Next.OpCode.Code -ne 'Ret') { throw 'Loc.F English branch shape changed.' }
$runtimeFormat = @($runtimeType.Methods | Where-Object { $_.Name -eq 'Format' -and $_.IsStatic -and $_.Parameters.Count -eq 1 -and $_.Parameters[0].ParameterType.FullName -eq 'System.FormattableString' -and $_.ReturnType.FullName -eq 'System.String' })
if ($runtimeFormat.Count -ne 1) { throw 'Runtime.Format signature does not match.' }
$toString[0].OpCode = [Mono.Cecil.Cil.OpCodes]::Call
$toString[0].Operand = $java.MainModule.ImportReference($runtimeFormat[0])
$ui = $app.MainModule.Types | Where-Object FullName -eq 'JavaMarket.UI.Ui'
$fontRef = $app.MainModule.ImportReference($getFont[0])
$current = $app.MainModule.ImportReference(($loc.Methods | Where-Object Name -eq 'get_Current'))
$fontMethods = @('get_Font','get_BoldFont','get_MonoFont')
for ($kind=0; $kind -lt 3; $kind++) {
    $getter = @($ui.Methods | Where-Object Name -eq $fontMethods[$kind])
    if ($getter.Count -ne 1 -or $getter[0].ReturnType.FullName -ne 'UnityEngine.Font') { throw ('Font getter changed: '+$fontMethods[$kind]) }
    $getter = $getter[0]; $il = $getter.Body.GetILProcessor(); $original = $getter.Body.Instructions[0]
    $clearNull = [Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Pop)
    $prefix = @(
        [Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Call,$current),
        [Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ldc_I4_1),
        [Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Bne_Un,$original),
        [Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ldc_I4,[int]$kind),
        [Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Call,$fontRef),
        [Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Dup),
        [Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Brfalse,$clearNull),
        [Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ret),
        $clearNull
    )
    foreach ($instruction in $prefix) { $il.InsertBefore($original,$instruction) }
}
$java.Write((Join-Path $output 'JavaMarket.Java.dll'))
$app.Write((Join-Path $output 'JavaMarket.dll'))
$java.Dispose(); $app.Dispose(); $runtime.Dispose()
$manifest = [ordered]@{ patchedAtUtc=[DateTime]::UtcNow.ToString('o'); runtime=$runtimeName; helperSha256=(Get-FileHash -LiteralPath $runtimePath -Algorithm SHA256).Hash; source=@{}; patched=@{}; methods=@('JavaMarket.Loc.T','JavaMarket.Loc.F','JavaMarket.UI.Ui.get_Font','JavaMarket.UI.Ui.get_BoldFont','JavaMarket.UI.Ui.get_MonoFont') }
foreach ($name in @('JavaMarket.Java.dll','JavaMarket.dll')) {
    $manifest.source[$name] = (Get-FileHash -LiteralPath (Join-Path $managed $name) -Algorithm SHA256).Hash
    $manifest.patched[$name] = (Get-FileHash -LiteralPath (Join-Path $output $name) -Algorithm SHA256).Hash
    $check = [Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $output $name)); $check.Dispose()
}
$manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $output 'patch-manifest.json') -Encoding utf8
Write-Output ('Patched assembly copies verified in ' + $output)




