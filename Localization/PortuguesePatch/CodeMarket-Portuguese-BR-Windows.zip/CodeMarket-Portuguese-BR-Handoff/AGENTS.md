# Code Market — pt-BR

Leia AI-HANDOFF.txt antes de trabalhar. Use esta pasta como raiz. Preserve traduções, saves, código e mods existentes. Não ignore incompatibilidades de hash. Separe testes executados de limitações. Commits devem ser em coreano.
