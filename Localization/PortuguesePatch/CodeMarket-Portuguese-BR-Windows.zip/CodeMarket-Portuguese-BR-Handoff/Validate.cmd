@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Validate.ps1" %*
pause
