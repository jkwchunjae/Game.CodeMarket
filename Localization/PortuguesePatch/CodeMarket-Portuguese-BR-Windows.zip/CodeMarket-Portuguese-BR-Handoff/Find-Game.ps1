﻿function Resolve-CodeMarketDirectory {
    param([string]$GameDirectory)
    if ($GameDirectory) {
        $explicit = (Resolve-Path -LiteralPath $GameDirectory -ErrorAction Stop).Path
        if (-not (Test-Path -LiteralPath (Join-Path $explicit 'Code Market.exe'))) { throw 'Code Market.exe was not found in the specified directory.' }
        return $explicit
    }
    $roots = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($key in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')) {
        $settings = Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
        foreach ($value in @($settings.SteamPath, $settings.InstallPath)) { if ($value) { $null = $roots.Add($value) } }
    }
    foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) {
        if ($base) { $null = $roots.Add((Join-Path $base 'Steam')) }
    }
    foreach ($drive in Get-PSDrive -PSProvider FileSystem) {
        foreach ($suffix in @('SteamLibrary','Steam','Games\Steam')) { $null = $roots.Add((Join-Path $drive.Root $suffix)) }
    }
    foreach ($root in @($roots)) {
        $libraryFile = Join-Path $root 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $libraryFile) {
            $vdf = Get-Content -LiteralPath $libraryFile -Raw
            foreach ($match in [regex]::Matches($vdf, '"path"\s*"((?:\\.|[^"\\])*)"')) {
                $null = $roots.Add($match.Groups[1].Value.Replace('\\','\'))
            }
        }
    }
    $found = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($root in $roots) {
        $candidate = Join-Path $root 'steamapps\common\Code Market'
        if (Test-Path -LiteralPath (Join-Path $candidate 'Code Market.exe')) { $null = $found.Add((Resolve-Path -LiteralPath $candidate).Path) }
    }
    if ($found.Count -eq 1) { foreach ($candidate in $found) { return $candidate } }
    if ($found.Count -gt 1) { throw ('Multiple installations found. Specify -GameDirectory explicitly: ' + (($found | Sort-Object) -join '; ')) }
    throw 'Game not found. Install Code Market with Steam, or specify -GameDirectory with its installation folder.'
}
