﻿param([string]$GameDirectory)
$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'Validate.ps1')
. (Join-Path $PSScriptRoot 'Find-Game.ps1')
$game = Resolve-CodeMarketDirectory -GameDirectory $GameDirectory
$managed = Join-Path $game 'Code Market_Data\Managed'
if (-not (Test-Path -LiteralPath (Join-Path $game 'Code Market.exe'))) { throw 'Code Market.exe was not found.' }
if (Get-Process -Name 'Code Market' -ErrorAction SilentlyContinue) { throw 'Close Code Market before installing.' }
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'patched\patch-manifest.json') -Raw | ConvertFrom-Json
$state = Join-Path $game 'PortuguesePatch'
$backupKey = $manifest.source.'JavaMarket.Java.dll'.Substring(0,16) + '-' + $manifest.source.'JavaMarket.dll'.Substring(0,16)
$backup = Join-Path $state ('originals\' + $backupKey)
$names = @('JavaMarket.Java.dll','JavaMarket.dll')
function Hash([string]$file) { return (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash }
if ((Hash (Join-Path $PSScriptRoot 'PortuguesePatch.Runtime.dll')) -ne $manifest.helperSha256) { throw 'Runtime hash mismatch.' }
# Verify everything before changing the installation. Refuse unknown game updates/mods.
foreach ($name in $names) {
    $current = Hash (Join-Path $managed $name)
    if ($current -ne $manifest.source.$name -and $current -ne $manifest.patched.$name) { throw "Unsupported game version or another mod: $name" }
    if ((Hash (Join-Path $PSScriptRoot "patched\$name")) -ne $manifest.patched.$name) { throw "Damaged patch file: $name" }
    $saved = Join-Path $backup $name
    if ((Test-Path -LiteralPath $saved) -and (Hash $saved) -ne $manifest.source.$name) { throw "Original backup hash mismatch: $name" }
    if ($current -eq $manifest.patched.$name -and -not (Test-Path -LiteralPath $saved)) { throw "Missing original backup: $name" }
}
$helper = Join-Path $managed 'PortuguesePatch.Runtime.dll'
if ((Test-Path -LiteralPath $helper) -and -not (Test-Path -LiteralPath (Join-Path $state 'installed-manifest.json'))) { throw 'An unmanaged PortuguesePatch.Runtime.dll already exists.' }
New-Item -ItemType Directory -Path $backup -Force | Out-Null
foreach ($name in $names) {
    $saved = Join-Path $backup $name
    if (-not (Test-Path -LiteralPath $saved)) { Copy-Item -LiteralPath (Join-Path $managed $name) -Destination $saved }
}
$oldTranslation = Join-Path $state 'pt-BR.json'
$transaction = Join-Path $state ('history\' + [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss-fff') + '-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $transaction -Force | Out-Null
$targets = @(
    @{Path=(Join-Path $managed 'JavaMarket.Java.dll'); Name='JavaMarket.Java.dll'},
    @{Path=(Join-Path $managed 'JavaMarket.dll'); Name='JavaMarket.dll'},
    @{Path=$helper; Name='PortuguesePatch.Runtime.dll'},
    @{Path=$oldTranslation; Name='pt-BR.json'},
    @{Path=(Join-Path $state 'installed-manifest.json'); Name='installed-manifest.json'}
)
foreach ($target in $targets) {
    $target.Existed = Test-Path -LiteralPath $target.Path
    if ($target.Existed) { Copy-Item -LiteralPath $target.Path -Destination (Join-Path $transaction $target.Name) }
}
try {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'PortuguesePatch.Runtime.dll') -Destination $helper -Force
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'pt-BR.json') -Destination $oldTranslation -Force
    foreach ($name in $names) { Copy-Item -LiteralPath (Join-Path $PSScriptRoot "patched\$name") -Destination (Join-Path $managed $name) -Force }
    foreach ($name in $names) { if ((Hash (Join-Path $managed $name)) -ne $manifest.patched.$name) { throw "Installed hash mismatch: $name" } }
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'patched\patch-manifest.json') -Destination (Join-Path $state 'installed-manifest.json') -Force
} catch {
    foreach ($target in $targets) {
        if ($target.Existed) { Copy-Item -LiteralPath (Join-Path $transaction $target.Name) -Destination $target.Path -Force }
        elseif (Test-Path -LiteralPath $target.Path) { Remove-Item -LiteralPath $target.Path }
    }
    throw
}
Write-Output 'INSTALADO. Abra o jogo pelo Steam e selecione English para ativar o português brasileiro.'
