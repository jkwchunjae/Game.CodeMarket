﻿$ErrorActionPreference = 'Stop'
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'package-files.json') -Raw -Encoding utf8 | ConvertFrom-Json
$root = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
foreach ($entry in $manifest.files) {
    $file = [IO.Path]::GetFullPath((Join-Path $root $entry.path))
    if (-not $file.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid package manifest path.' }
    if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Changed or damaged package file: $($entry.path)" }
}
Write-Output "PACKAGE VERIFIED: $($manifest.files.Count) original package files."
Write-Output 'A pt-BR.json mismatch after intentionally editing your translation is expected; use Validate.ps1 for translation checks.'
