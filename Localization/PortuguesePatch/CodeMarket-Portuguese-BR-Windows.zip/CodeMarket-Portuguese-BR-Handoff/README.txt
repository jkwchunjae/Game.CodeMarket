CODE MARKET — PORTUGUÊS BRASILEIRO (pt-BR)

1. Salve e feche o jogo. Extraia TODO o ZIP para uma pasta.
2. Dê dois cliques em Install.cmd. Aguarde a mensagem INSTALADO.
3. Abra o jogo pelo Steam. Em Settings > Language, escolha English.
   A opção English passa a mostrar português brasileiro.

Para remover: feche o jogo e execute Uninstall.cmd.
Para conferir os arquivos: execute Validate.cmd e Check.cmd.
Não copie os DLLs manualmente: o instalador verifica a versão e cria backups.
Se a instalação estiver em Program Files e o Windows negar acesso, execute
Install.cmd como administrador. Não é necessário alterar permissões da pasta.

Se já houver a tradução coreana ou outro mod, primeiro remova-o usando o
seu desinstalador. Esta versão preserva as verificações de compatibilidade
e recusa DLLs de outra versão ou de outro mod. Não force a instalação.
Depois de uma atualização do jogo, pode ser necessário atualizar a tradução.

São 2.499 entradas: menus, guia, tutoriais, produtos, melhorias e mensagens
de erro de programação. Nomes de APIs, Java, C#, C++ e código são preservados.
A tradução é uma versão inicial: ainda precisa de revisão em contexto por
um falante brasileiro e conferência visual de todas as telas.

Para corrigir uma tradução, edite somente ptBR em pt-BR.json (UTF-8).
Preserve {0}, {1}, formatos como {0:N0}, tags e exemplos de código.
Execute Validate.cmd e depois Apply-Translations.cmd; reinicie o jogo.
O arquivo é carregado uma vez por execução. Não há troca automática em tempo real.
Os backups ficam em PortuguesePatch/originals dentro da pasta do jogo;
as traduções anteriores ficam em PortuguesePatch/history.
Não distribua esses backups, saves ou arquivos de conta.

Para quem usa IA: leia AI-HANDOFF.txt. O pacote contém fontes e ferramentas
para manutenção. Não é necessário instalar SDK, Unity, Python ou Node.js
para a instalação normal no Windows.

Este é um patch de comunidade. Os binários modificados derivam dos pacotes
coreanos fornecidos como referência; este pacote não inclui o jogo completo.
Confira verification.txt para os testes realmente executados e suas limitações.
