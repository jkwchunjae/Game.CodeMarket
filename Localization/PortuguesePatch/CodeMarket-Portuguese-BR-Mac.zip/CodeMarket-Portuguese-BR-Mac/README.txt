CODE MARKET PARA MAC — PORTUGUÊS BRASILEIRO (pt-BR)

1. Salve e feche o jogo. Extraia TODO o ZIP.
2. Dê dois cliques em Install.command.
3. Abra o jogo pelo Steam e escolha English em Settings > Language.
   O caminho English passa a exibir português brasileiro.

Para remover: feche o jogo e abra Uninstall.command.
Requer Python 3 disponível em /usr/bin/python3, como no pacote de referência.
Se o macOS pedir as ferramentas de linha de comando para obter Python,
conclua a instalação oferecida pelo sistema e tente novamente.

Local padrão:
~/Library/Application Support/Steam/steamapps/common/Code Market/Code Market.app
Se estiver em outra biblioteca, abra o Terminal nesta pasta e execute:
python3 install.py "/caminho/para/Code Market.app"
Para remover dessa localização:
python3 install.py --uninstall "/caminho/para/Code Market.app"

Se o Terminal disser "permission denied", execute nesta pasta:
chmod +x Install.command Uninstall.command
Se o macOS bloquear a abertura, tente Control + clique > Abrir.
Não desative a proteção do sistema nem execute o instalador com sudo.

Uma tradução coreana ou outro mod precisa ser removido antes.
Uma versão diferente do jogo será recusada. Não force a cópia dos DLLs.
Backups e histórico: PortuguesePatch-Mac ao lado de Code Market.app.
Ao remover, os DLLs originais são restaurados e a tradução é preservada.

As 2.499 entradas incluem menus, guia, tutoriais e erros de programação.
Código e APIs são preservados. A tradução é uma versão inicial, ainda sem
revisão completa em contexto por um falante brasileiro.
Para editar, veja AI-HANDOFF.txt. É necessário reiniciar o jogo.

Pacote preparado e verificado em Windows. Os DLLs Mac derivam do pacote
Mac fornecido, mantendo sua verificação de versão original. Não foi possível
executar o jogo nem o instalador no macOS. Consulte verification.txt.
