#!/bin/zsh
cd -- "${0:A:h}" || exit 1
/usr/bin/python3 ./install.py
result=$?
printf '\nPressione Enter para fechar. '
read answer
exit $result
