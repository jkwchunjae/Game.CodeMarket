#!/usr/bin/env python3
import hashlib, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path
from datetime import datetime
KIT=Path(__file__).resolve().parent
DEFAULT=Path.home()/'Library/Application Support/Steam/steamapps/common/Code Market/Code Market.app'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def require(ok,msg):
 if not ok: raise RuntimeError(msg)
def atomic(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 fd,tmp=tempfile.mkstemp(prefix='.pt-br-',dir=str(dst.parent));os.close(fd)
 try:
  shutil.copy2(src,tmp);os.replace(tmp,dst)
 finally:
  if os.path.exists(tmp): os.unlink(tmp)

def validate_translations(document):
 import re
 source=json.loads((KIT/'source-strings.json').read_text(encoding='utf-8-sig'))
 expected={(t['name'],i,e['en']):e for t in source['tables'] for i,e in enumerate(t['entries'])}
 entries=document.get('entries',[])
 require(len(entries)==len(expected),'Quantidade de traduções incorreta')
 seen=set(); translations={}
 patterns=[r'(?<!\{)\{\d+(?:,[^{}]+)?(?::[^{}]+)?\}(?!\})',r'</?(?:b|i|color|size|material|quad)(?:=[^>]+|\s[^>]+)?>']
 for e in entries:
  key=(e.get('table'),e.get('index'),e.get('en'))
  require(key in expected and key not in seen,'Entrada desconhecida ou duplicada')
  seen.add(key); text=e.get('ptBR')
  require(isinstance(text,str) and bool(text.strip()),'Tradução vazia ou inválida')
  for pattern in patterns: require(sorted(re.findall(pattern,e['en']))==sorted(re.findall(pattern,text)),'Marcadores ou tags alterados: '+str(key[:2]))
  normalized=e['en'].replace('\r\n','\n').replace('\r','\n')
  require(normalized not in translations or translations[normalized]==text,'Traduções conflitantes')
  translations[normalized]=text

def main():
 undo='--uninstall' in sys.argv
 args=[a for a in sys.argv[1:] if a!='--uninstall']
 app=Path(args[0]).expanduser().resolve() if args else DEFAULT
 resources=app/'Contents/Resources';managed=resources/'Data/Managed'
 require(managed.is_dir(),'Instalação do jogo não encontrada: '+str(app))
 proc=subprocess.run(['/usr/bin/pgrep','-x','Java Supermarket'],capture_output=True)
 require(proc.returncode==1,'Salve e feche o jogo antes de continuar. Também interrompemos se não for possível verificar se está em execução.')
 manifest=json.loads((KIT/'patched/patch-manifest.json').read_text(encoding='utf-8-sig'))
 state=app.parent/'PortuguesePatch-Mac'
 originals=state/'originals'/('-'.join(manifest['source'][n][:16] for n in sorted(manifest['source'])))
 targets={n:managed/n for n in manifest['source']}
 targets['PortuguesePatch.Runtime.dll']=managed/'PortuguesePatch.Runtime.dll'
 targets['pt-BR.json']=resources/'PortuguesePatch/pt-BR.json'
 require(digest(KIT/'PortuguesePatch.Runtime.dll')==manifest['helperSha256'],'Falha de integridade do runtime da tradução')
 for n,h in manifest['patched'].items(): require(digest(KIT/'patched'/n)==h,'Falha de integridade do arquivo: '+n)
 current={n:digest(managed/n) for n in manifest['source']}
 pristine=current==manifest['source'];patched=current==manifest['patched']
 require(pristine or patched,'Versão incompatível ou outro mod instalado. Nenhum arquivo foi alterado.')
 if undo:
  require(patched,'Esta tradução não está instalada.')
  require(targets['PortuguesePatch.Runtime.dll'].exists() and digest(targets['PortuguesePatch.Runtime.dll'])==manifest['helperSha256'],'O runtime foi modificado. Restauração interrompida.')
 else:
  for n in ('pt-BR.json','PortuguesePatch.Runtime.dll'):
   if targets[n].exists(): require(digest(targets[n])==digest(KIT/n),'Tradução ou runtime existente é diferente. Operação interrompida para preservá-lo: '+n)
 if not undo:
  document=json.loads((KIT/'pt-BR.json').read_text(encoding='utf-8-sig'))
  validate_translations(document)
 if pristine:
  originals.mkdir(parents=True,exist_ok=True)
  for n,h in manifest['source'].items():
   if (originals/n).exists(): require(digest(originals/n)==h,'Falha de integridade do backup original')
   else: shutil.copy2(managed/n,originals/n)
 for n,h in manifest['source'].items(): require((originals/n).exists() and digest(originals/n)==h,'Backup original verificado não encontrado: '+n)
 history=state/'history'/(datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
 history.mkdir(parents=True)
 existed={n:p.exists() for n,p in targets.items()}
 for n,p in targets.items():
  if p.exists(): shutil.copy2(p,history/n)
 shutil.copy2(KIT/'patched/patch-manifest.json',state/'patch-manifest.json')
 try:
  for n in manifest['source']: atomic((originals if undo else KIT/'patched')/n,targets[n])
  if undo: targets['PortuguesePatch.Runtime.dll'].unlink()
  else:
   atomic(KIT/'PortuguesePatch.Runtime.dll',targets['PortuguesePatch.Runtime.dll'])
   atomic(KIT/'pt-BR.json',targets['pt-BR.json'])
  for n,h in (manifest['source'] if undo else manifest['patched']).items(): require(digest(targets[n])==h,'Falha na verificação após a instalação: '+n)
  if not undo:
   for n in ('pt-BR.json','PortuguesePatch.Runtime.dll'): require(digest(targets[n])==digest(KIT/n),'Falha na verificação após a instalação: '+n)
 except BaseException:
  for n,p in targets.items():
   if existed[n]: atomic(history/n,p)
   elif p.exists(): p.unlink()
  raise
 print('Restauração concluída. Tradução e backups preservados.' if undo else 'Tradução para português brasileiro instalada! Abra o jogo pelo Steam e selecione English nas configurações de idioma.')
 print('Backup: '+str(originals))
if __name__=='__main__':
 try: main()
 except Exception as e: print('Operação interrompida: '+str(e),file=sys.stderr);sys.exit(1)
